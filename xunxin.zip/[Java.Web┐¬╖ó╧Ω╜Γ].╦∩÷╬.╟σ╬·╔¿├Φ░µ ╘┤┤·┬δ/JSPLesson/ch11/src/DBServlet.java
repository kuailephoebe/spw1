import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;

public class DBServlet extends HttpServlet
{
    final static String driver="com.mysql.jdbc.Driver";
    final static String url="jdbc:mysql://localhost:3306/bookstore";
    final static String user="root";
    final static String password="12345678";
    
    public synchronized void doGet(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        try
        {
            Class.forName(driver);
            Connection conn=DriverManager.getConnection(url,user,password);
        }
        catch(Exception ce)
        {
            throw new UnavailableException("�������ݿ�����ʧ�ܣ�");
        }
        ...   
    }
}
