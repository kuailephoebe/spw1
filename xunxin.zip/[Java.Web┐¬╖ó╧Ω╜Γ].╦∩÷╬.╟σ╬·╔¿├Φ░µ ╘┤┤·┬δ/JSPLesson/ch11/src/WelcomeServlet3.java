import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;

public class WelcomeServlet3 extends HttpServlet
{
    String user="";
    public synchronized void doGet(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        user=req.getParameter("user");
        String welcomeInfo="Welcome you, "+user;
        
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();        
        out.println("<html><head><title>Welcome Page</title><body>");
        out.println(welcomeInfo);
        out.println("</body></head></html>");
        out.close();
    }
}
