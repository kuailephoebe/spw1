import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;

public class WelcomeServlet2 extends HttpServlet
{
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        String user="";
        user=req.getParameter("user");
        String welcomeInfo="Welcome you, "+user;
        
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();        
        out.println("<html><head><title>Welcome Page</title><body>");
        out.println(welcomeInfo);
        out.println("</body></head></html>");
        out.close();
    }
}
