import java.io.*;
import java.sql.*;

import javax.servlet.*;
import javax.servlet.http.*;

import javax.naming.*;
import javax.sql.DataSource;


public class TestServlet2 extends HttpServlet
{
    DataSource ds=null;
    public void init() 
    {
        try
        {
            Context ctx = new InitialContext();
            ds = (DataSource)ctx.lookup("java:comp/env/jdbc/bookstore");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response)
                   throws ServletException, java.io.IOException
    {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try 
        {
            conn = ds.getConnection(); //�����ӳ��еõ�����
            stmt = conn.createStatement();
            rs = stmt.executeQuery("...");
            ...
            
            rs.close();
            stmt.close();
            conn.close(); //���ӱ��Ż����ӳ�
            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        finally
        {
            if (rs != null)
            {
                try 
                { 
                    rs.close(); 
                } 
                catch (Exception ex) 
                {
                    System.out.println(ex);
                }
            }
            if (stmt != null) 
            {
                try 
                { 
                    stmt.close(); 
                } 
                catch(Exception ex) 
                {
                    System.out.println(ex);
                }
            }
            if (conn != null)
            {
                try 
                { 
                    conn.close(); 
                }
                catch(Exception ex) 
                {
                    System.out.println(ex);
                }
            }
        }
    }
}