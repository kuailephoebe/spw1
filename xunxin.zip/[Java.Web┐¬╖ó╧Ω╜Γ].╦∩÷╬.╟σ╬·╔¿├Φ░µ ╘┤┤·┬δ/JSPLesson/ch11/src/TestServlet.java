import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*

import javax.sql.DataSource;
import java.sql.*
import javax.naming.*;

public class TestServlet extends HttpServlet
{
    Statement stmt;
    ResultSet rs;
    DataSource ds;
    
    public void init() 
    {
        try
        {
            Context ctx = new InitialContext();
            ds = (DataSource)ctx.lookup("java:comp/env/jdbc/bookstore");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response)
                   throws ServletException, java.io.IOException
    {
        Connection conn=null;
        try
        {
            if (ds != null)
            {
                conn = ds.getConnection();
                if(conn!= null)
                {
                    stmt = conn.createStatement();
                }
                ...
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        finally
        {
            if (rs != null)
            {
                try 
                { 
                    rs.close(); 
                } 
                catch (Exception ex) 
                {
                    System.out.println(ex);
                }
            }
            if (stmt != null) 
            {
                try 
                { 
                    stmt.close(); 
                } 
                catch(Exception ex) 
                {
                    System.out.println(ex);
                }
            }
            if (conn != null)
            {
                try 
                { 
                    conn.close(); 
                }
                catch(Exception ex) 
                {
                    System.out.println(ex);
                }
            }
        }
    }
}
