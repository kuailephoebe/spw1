package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.List;
import java.util.Iterator;
import org.apache.commons.fileupload.*;
import javax.naming.*;
import java.sql.*;
import javax.sql.DataSource;
import java.io.File;

public final class upload2_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=GBK");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n\r\n\r\n\r\n\r\n<html>\r\n    <head><title>upload2</title></head>\r\n    <body>\r\n    ");

        DiskFileUpload dfu=new DiskFileUpload();
        //设置上传数据的最大大小为10M。
        dfu.setSizeMax(0xA00000);

        //设置内存缓冲区的阀值为512K。
        dfu.setSizeThreshold(0x80000);

        //设置临时存储文件的目录为E:\fileupload。
        dfu.setRepositoryPath("E:\\fileupload");

        //得到FileItem对象的列表。
        List fileItems=dfu.parseRequest(request);
        Iterator it = fileItems.iterator();

        Context ctx=new InitialContext();
        DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc/bookstore");
        Connection conn=ds.getConnection();
        PreparedStatement pstmt=conn.prepareStatement("insert into uploadfile(filename,filesize,data) values(?,?,?)");

        //依次处理每个上传的文件
        while (it.hasNext())
        {
            FileItem item = (FileItem) it.next();
            //判断是否是文件域的表单信息
            if (!item.isFormField())
            {
                String name = item.getName();
                //如果浏览器传送的文件名是全路径名，则取出文件名。
                int index=name.lastIndexOf(File.separator);
                if(index>0)
                    name=name.substring(index+1,name.length());

                long size = item.getSize();
                if((name==null || name.equals("")) && size==0)
                    continue;
                pstmt.setString(1,name);
                pstmt.setInt(2,(int)size);
                pstmt.setBinaryStream(3,item.getInputStream(),(int)size);
                pstmt.executeUpdate();
            }
        }
        if(pstmt!=null)
        {
            pstmt.close();
            pstmt=null;
        }
        if(conn!=null)
        {
            conn.close();
            conn=null;
        }
        out.println("上传成功！");
    
      out.write("\r\n    </body>\r\n</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
