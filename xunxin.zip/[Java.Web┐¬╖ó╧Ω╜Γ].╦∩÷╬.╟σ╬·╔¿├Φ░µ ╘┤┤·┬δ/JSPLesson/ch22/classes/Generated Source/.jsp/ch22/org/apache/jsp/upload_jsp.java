package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.List;
import java.util.Iterator;
import org.apache.commons.fileupload.*;
import java.io.File;

public final class upload_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=GBK");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n\r\n\r\n\r\n<html>\r\n    <head><title>upload</title></head>\r\n    <body>\r\n    ");

        DiskFileUpload dfu=new DiskFileUpload();
        //设置上传数据的最大大小为10M。
        dfu.setSizeMax(0xA00000);

        //设置内存缓冲区的阀值为512K。
        dfu.setSizeThreshold(0x80000);

        //设置临时存储文件的目录为E:\fileupload。
        dfu.setRepositoryPath("E:\\fileupload");

        //得到FileItem对象的列表。
        List fileItems=dfu.parseRequest(request);
        Iterator it = fileItems.iterator();
    
      out.write("\r\n        <table cellpadding=\"3\" border=\"1\">\r\n    ");

        //依次处理每个上传的文件
        while (it.hasNext())
        {
            FileItem item = (FileItem) it.next();
            //判断是否是文件域的表单信息
            if (!item.isFormField())
            {
                String name = item.getName();
                long size = item.getSize();
                if((name==null || name.equals("")) && size==0)
                    continue;
    
      out.write("\r\n            <tr>\r\n                <td>");
      out.print(item.getName());
      out.write("</td>\r\n                <td>");
      out.print(item.getSize());
      out.write("</td>\r\n            </tr>\r\n    ");

                //保存上传的文件到指定的目录
                File dir=new File("E:\\UploadFile");
                //如果浏览器传送的文件名是全路径名，则取出文件名。
                int index=name.lastIndexOf(File.separator);
                if(index>0)
                    name=name.substring(index+1,name.length());

                File file=new File(dir,name);
                item.write(file);
            }
            else
            {
    
      out.write("\r\n            <tr>\r\n                <td>");
      out.print(item.getFieldName());
      out.write("</td>\r\n                <td>");
      out.print(item.getString());
      out.write("</td>\r\n            </tr>\r\n    ");

            }
        }
    
      out.write("\r\n        </table>\r\n    </body>\r\n</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
