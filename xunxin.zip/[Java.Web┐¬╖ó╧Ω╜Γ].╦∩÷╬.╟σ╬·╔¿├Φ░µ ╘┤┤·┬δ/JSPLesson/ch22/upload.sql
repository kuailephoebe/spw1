create table uploadfile(
    id INT AUTO_INCREMENT primary key,
    filename VARCHAR(255) not null,
    filesize INT not null,
    data MEDIUMBLOB not null);