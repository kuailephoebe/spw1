package org.sunxin.lesson.jsp.ch16;

public class MyFuncs
{
    public static String toGBK(String str,String charset)
               throws java.io.UnsupportedEncodingException
    {
        return new String(str.getBytes(charset),"GBK");
    }
}
