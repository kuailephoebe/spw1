package org.sunxin.lesson.jsp.bookstore;

import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;

public class CreateAccountServlet extends HttpServlet
{
    private String url;
    private String user;
    private String password;
    
    public void init() throws ServletException
    {
        ServletContext sc=getServletContext();
        String driverClass=sc.getInitParameter("driverClass");
        url=sc.getInitParameter("url");
        user=sc.getInitParameter("user");
        password=sc.getInitParameter("password");
        try
        {
            Class.forName(driverClass);
        }
        catch(ClassNotFoundException ce)
        {
            throw new UnavailableException("�������ݿ�����ʧ�ܣ�");
        }
    }
    
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        Connection conn=null;
        Statement stmt=null;
        PreparedStatement pstmt=null;
        try
        {
            conn=DriverManager.getConnection(url,user,password);
            stmt=conn.createStatement();
            
            stmt.executeUpdate("create table account(userid VARCHAR(10) not null primary key,balance FLOAT(6,2)) ENGINE=InnoDB");
            
            pstmt=conn.prepareStatement("insert account values(?,?)");
            
            pstmt.setString(1,"��");
            pstmt.setFloat(2,500.00f);
            pstmt.executeUpdate();
            
            pstmt.setString(1,"��");
            pstmt.setFloat(2,200.00f);
            pstmt.executeUpdate();
            
            PrintWriter out=resp.getWriter();
            out.println("success!");
            out.close();
        }
        catch(SQLException se)
        {
            se.printStackTrace();
        }
        finally
        {
            if(stmt!=null)
            {
                try
                {
                    stmt.close();
                }
                catch(SQLException se)
                {
                    se.printStackTrace();
                }
                stmt=null;
            }
            if(pstmt!=null)
            {
                try
                {
                    pstmt.close();
                }
                catch(SQLException se)
                {
                    se.printStackTrace();
                }
                pstmt=null;
            }
            if(conn!=null)
            {
                try
                {
                    conn.close();
                }
                catch(SQLException se)
                {
                    se.printStackTrace();
                }
                conn=null;
            }
        }
    }
}