package org.sunxin.lesson.jsp.bookstore;

import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.ArrayList;
import javax.sql.*;
import javax.naming.*;

public class GetDBInfoServlet2 extends HttpServlet
{
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        Connection conn=null;
        Statement stmt=null;
        ResultSet rs=null;
        
        try
        {
            Context ctx=new InitialContext();
            DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc/bookstore");
            conn=ds.getConnection();
            
            resp.setContentType("text/html;charset=gb2312");
            PrintWriter out=resp.getWriter();
            out.println("<html><head>");
            out.println("<title>���ݿ������Ϣ</title>");
            out.println("</head><body>");
            
            String tableName=req.getParameter("tableName");
            if(null==tableName || tableName.equals(""))
            {
                DatabaseMetaData dbMeta=conn.getMetaData();
                rs=dbMeta.getTables(null,null,null,new String[]{"TABLE"});
                out.println("<form action=\"getdbinfo\" method=\"get\">");
                out.println("<select size=1 name=tableName>");
                while(rs.next())
                {
                    out.println("<option value="+rs.getString("TABLE_NAME")+">");
                    out.println(rs.getString("TABLE_NAME"));
                    out.println("</option>");
                }
                out.println("</select><p>");
                out.println("<input type=\"submit\" value=\"�ύ\">");
                out.println("</form>");
            }
            else
            {
                stmt=conn.createStatement();
                rs=stmt.executeQuery("select * from "+tableName); 
                ResultSetMetaData rsMeta=rs.getMetaData();
                int columnCount=rsMeta.getColumnCount();
                out.println("<table border=1>");
                out.println("<caption>���Ľṹ</catption>");
                out.println("<tr><th>�ֶ���</th><th>�ֶ�����</th><th>����ַ�����</th></tr>");
                
                ArrayList<String> al=new ArrayList<String>();
                for(int i=1;i<=columnCount;i++)
                {
                    out.println("<tr>");
                    String columnName=rsMeta.getColumnName(i);
                    out.println("<td>"+columnName+"</td>");
                    al.add(columnName);
                    out.println("<td>"+rsMeta.getColumnTypeName(i)+"</td>");
                    out.println("<td>"+rsMeta.getColumnDisplaySize(i)+"</td>");
                }
                out.println("</table><p>");
                
                out.println("<table border=1>");
                out.println("<caption>���е�����</catption>");
                out.println("<tr>");
                
                for(int i=0;i<columnCount;i++)
                {
                    out.println("<th>"+al.get(i)+"</th>");
                }
                
                while(rs.next())
                {
                    out.println("<tr>");
                    for(int i=1;i<=columnCount;i++)
                    {
                        out.println("<td>"+rs.getString(i)+"</td>");    
                    }
                    out.println("</tr>");
                }
                out.println("</table>");
            }
            out.println("</body><html>");
            out.close();
        }
        catch(NamingException ne)
        {
            ne.printStackTrace();
        }
        catch(SQLException se)
        {
            se.printStackTrace();
        }
        finally
        {
            if(rs!=null)
            {
                try
                {
                    rs.close();
                }
                catch(SQLException se)
                {
                    se.printStackTrace();
                }
                rs=null;
            }
            if(stmt!=null)
            {
                try
                {
                    stmt.close();
                }
                catch(SQLException se)
                {
                    se.printStackTrace();
                }
                stmt=null;
            }
            if(conn!=null)
            {
                try
                {
                    conn.close();
                }
                catch(SQLException se)
                {
                    se.printStackTrace();
                }
                conn=null;
            }
        }
    }
}