package org.sunxin.lesson.jsp.bookstore;

import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;

public class CreateDBServlet extends HttpServlet
{
    private String url;
    private String user;
    private String password;
    
    public void init() throws ServletException
    {
        String driverClass=getInitParameter("driverClass");
        url=getInitParameter("url");
        user=getInitParameter("user");
        password=getInitParameter("password");
        try
        {
            Class.forName(driverClass);
        }
        catch(ClassNotFoundException ce)
        {
            throw new UnavailableException("�������ݿ�����ʧ�ܣ�");
        }
    }
    
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        Connection conn=null;
        Statement stmt=null;
        try
        {
            conn=DriverManager.getConnection(url,user,password);
            stmt=conn.createStatement();
            stmt.executeUpdate("create database bookstore");
            stmt.executeUpdate("use bookstore");
            stmt.executeUpdate("create table bookinfo(id INT not null primary key,title VARCHAR(50) not null,author VARCHAR(50) not null,bookconcern VARCHAR(100) not null,publish_date DATE not null,price FLOAT(4,2) not null,amount SMALLINT,remark VARCHAR(200)) ENGINE=InnoDB");
            stmt.addBatch("insert into bookinfo values(1,'Java�����ŵ���ͨ','����','����������','2004-6-1',34.00,35,null)");
            stmt.addBatch("insert into bookinfo values(2,'JSP������','����','���ĳ�����','2004-10-1',56.00,20,null)");
            stmt.addBatch("insert into bookinfo values(3,'J2EE�߼����','����','���������','2005-3-1',78.00,10,null)");
            stmt.executeBatch();
            
            PrintWriter out=resp.getWriter();
            out.println("success!");
            out.close();
        }
        catch(SQLException se)
        {
            se.printStackTrace();
        }
        finally
        {
            if(stmt!=null)
            {
                try
                {
                    stmt.close();
                }
                catch(SQLException se)
                {
                    se.printStackTrace();
                }
                stmt=null;
            }
            if(conn!=null)
            {
                try
                {
                    conn.close();
                }
                catch(SQLException se)
                {
                    se.printStackTrace();
                }
                conn=null;
            }
        }
    }
}