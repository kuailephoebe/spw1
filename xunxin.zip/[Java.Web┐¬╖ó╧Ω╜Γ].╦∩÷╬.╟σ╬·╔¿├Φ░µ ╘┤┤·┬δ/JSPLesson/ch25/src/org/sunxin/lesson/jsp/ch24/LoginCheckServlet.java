package org.sunxin.lesson.jsp.ch24;

import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;

public class LoginCheckServlet extends HttpServlet
{
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        HttpSession session=req.getSession();
        String randomCode=(String)session.getAttribute("randomCode");
        if(null==randomCode)
        {
            resp.sendRedirect("login.html");
            return;
        }
        
        String reqRandom=req.getParameter("random");
        
        req.setCharacterEncoding("GBK");
        resp.setContentType("text/html;charset=gb2312");
        PrintWriter out=resp.getWriter();
        
        if(randomCode.equals(reqRandom))
        {
            
            out.println("��֤��ƥ�䣡");
        }
        else
        {
            out.println("��֤��У��ʧ�ܣ��뷵��ˢ��ҳ������!");
        }
        out.close();
    }
}