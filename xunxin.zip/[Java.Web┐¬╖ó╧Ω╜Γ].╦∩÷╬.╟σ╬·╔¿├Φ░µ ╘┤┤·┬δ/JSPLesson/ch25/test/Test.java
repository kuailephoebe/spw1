package mypackage;

import java.io.IOException;
public class Test
{
    public static void main(String[] args)
    {
        for(int i=0;i<args.length;i++)
        {
            System.out.println("command-line argument "+ (i+1) + ": " + args[i]);
        }
        int data=0;
        try
        {
            while((data=System.in.read())!='q')
		    {
			    System.out.print((char)data);
		    }
	    }
	    catch(IOException e)
	    {
	        System.err.println(e.getMessage());
	    }
		System.err.println("error");
    }
}