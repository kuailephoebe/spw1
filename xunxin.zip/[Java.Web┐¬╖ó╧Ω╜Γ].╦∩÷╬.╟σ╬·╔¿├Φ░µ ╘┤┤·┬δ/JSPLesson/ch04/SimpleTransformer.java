import javax.xml.transform.*;
import javax.xml.transform.stream.*;

public class SimpleTransformer
{
    public static void main(String[] args)
    {
        String srcFileName=null;
        String xslFileName=null;
        String outFileName=null;
        
        if(args.length!=6)
        {
            System.err.println("usage: java SimpleTransformer -IN source.xml -XSL stylesheet.xsl -OUT result.out");
            return;
        }
        for(int i=0;i<args.length;i++)
        {
            if("-IN".equalsIgnoreCase(args[i]))
            {
                if(i+1<args.length && args[i+1].charAt(0)!='-')
                    srcFileName=args[++i];
                else
                    throw new IllegalArgumentException("Missing argument for option -in.");
            }
            else if("-XSL".equalsIgnoreCase(args[i]))
            {
                if(i+1<args.length && args[i+1].charAt(0)!='-')
                    xslFileName=args[++i];
                else
                    throw new IllegalArgumentException("Missing argument for option -xsl.");
            }
            else if("-OUT".equalsIgnoreCase(args[i]))
            {
                if(i+1<args.length && args[i+1].charAt(0)!='-')
                    outFileName=args[++i];
                else
                    throw new IllegalArgumentException("Missing argument for option -out.");
            }
            else
            {
                throw new IllegalArgumentException("Invalid option");
            }
        }
        
        //�õ�ת�����������ʵ����
        TransformerFactory tFactory=TransformerFactory.newInstance();
        try
        {
            //ʹ��xslFileNameָ����XSLT�ĵ�����һ��Transformer����
            Transformer transformer=tFactory.newTransformer(new StreamSource(xslFileName));
            
            //��srcFileNameָ����XMLԴ�ĵ�ת��Ϊ����ĵ������浽outFileName�ļ��С�
            transformer.transform(new StreamSource(srcFileName),
                                  new StreamResult(outFileName));
        }
        catch(TransformerConfigurationException e){System.err.println(e.getMessage());}
        catch(TransformerException e){System.err.println(e.getMessage());}
    }
}