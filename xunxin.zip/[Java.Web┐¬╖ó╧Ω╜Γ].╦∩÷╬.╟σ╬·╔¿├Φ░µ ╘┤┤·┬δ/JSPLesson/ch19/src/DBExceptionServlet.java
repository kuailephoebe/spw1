package org.sunxin.lesson.jsp.ch19;

import java.io.*;
import java.sql.*;

import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.log4j.*;
import org.apache.log4j.xml.DOMConfigurator;

public class DBExceptionServlet extends HttpServlet
{
    static Logger logger=Logger.getRootLogger();
    static Logger bookLogger=Logger.getLogger("bookstoreLogger");
    
    public void init() throws ServletException
    {
        String prefix =  getServletContext().getRealPath("/");
        String file = getInitParameter("log4j-init-file");
        
        if(file != null)
        {
            //PropertyConfigurator.configure(prefix+file);
            DOMConfigurator.configure(prefix+file);
        }

        try
        {
            Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
            
        }
        catch(ClassNotFoundException ce)
        {
            throw new UnavailableException("�������ݿ�����ʧ�ܣ�");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {   
        Connection conn=null;
        Statement stmt=null;
        try
        {
            conn=DriverManager.getConnection(
            "jdbc:microsoft:sqlserver://localhost:1433;databasename=pubs","sa","1234");
            stmt=conn.createStatement();
            stmt.executeUpdate("delete from jobs where job_id=13");
        }
        catch(SQLException se)
        {
            NDC.push(req.getRemoteHost());
            logger.warn("���ݿ����ʧ��! "+se);
            logger.error("���ݿ����ʧ��! "+se);
            
            bookLogger.warn("���ݿ����ʧ��! "+se);
            bookLogger.error("���ݿ����ʧ��! "+se);
            
            NDC.pop();
            NDC.remove();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                        "���ݿ�����������⣬����ϵ����Ա��");
        }
        finally
        {
            if(stmt!=null)
            {
                try
                {
                    stmt.close();
                }
                catch(SQLException se)
                {
                    bookLogger.error("�ر�Statementʧ�ܣ�",se);
                }
                stmt=null;
            }
            if(conn!=null)
            {
                try
                {
                    conn.close();
                }
                catch(SQLException se)
                {
                    bookLogger.error("�ر����ݿ�����ʧ�ܣ�",se);
                }
                conn=null;
            }
        }
    }
}