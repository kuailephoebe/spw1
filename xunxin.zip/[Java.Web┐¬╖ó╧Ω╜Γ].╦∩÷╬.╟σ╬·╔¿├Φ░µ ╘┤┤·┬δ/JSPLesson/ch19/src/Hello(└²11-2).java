import org.apache.log4j.Logger;
//import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;

public class Hello
{

    static Logger logger = Logger.getLogger(Hello.class);

    public static void main(String args[])
    {
        //BasicConfigurator.configure();
        PropertyConfigurator.configure(args[0]);

        logger.debug("Hello world.");
        logger.info("Welcome you.");
    }
}
