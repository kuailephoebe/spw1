use bookstore;

create table logs(
    log_date DATETIME not null,
    log_logger VARCHAR(20) not null,
    log_level VARCHAR(5) not null,
    log_msg VARCHAR(200) not null);