create database guestbook;

GRANT ALL PRIVILEGES ON guestbook.* TO gst@localhost IDENTIFIED BY '12345678' WITH GRANT OPTION;

use guestbook;

create table users(
    username    VARCHAR(20),
    password    VARCHAR(16)     NOT NULL,
    email       VARCHAR(50)     NOT NULL,
    style       VARCHAR(10)     NOT NULL,
    PRIMARY KEY(username)
);

create table managers(
    username    VARCHAR(20),
    password    VARCHAR(16)     NOT NULL,
    PRIMARY KEY(username)
);

create table gst(
    gst_id      INT             AUTO_INCREMENT,
    gst_user    VARCHAR(20)     NOT NULL,
    gst_title   VARCHAR(100)    NOT NULL,
    gst_content TEXT,
    gst_time    TIMESTAMP       NOT NULL,
    gst_ip      VARCHAR(15)     NOT NULL,
    PRIMARY KEY(gst_id),
    CONSTRAINT FK_USER FOREIGN KEY (gst_user) REFERENCES users(username)
);

insert into managers values('sunxin','1234');