package org.sunxin.guestbook;

public class UserException extends GuestbookException
{
    public UserException(String msg)
    {
        super(msg);
    }
}
