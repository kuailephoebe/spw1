package org.sunxin.guestbook;

public class GuestbookException extends Exception
{
    public GuestbookException(String msg)
    {
        super(msg);
    }
}
