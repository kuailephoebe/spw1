package org.sunxin.lesson.jsp.ch14;

import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;

public class ControllerServlet extends HttpServlet
{
    public void service(HttpServletRequest request, HttpServletResponse response)
                 throws ServletException,IOException
    {
        request.setCharacterEncoding("GBK");
        response.setContentType("text/html;charset=GBK");
        
        String action=request.getParameter("action");
        
        if (!isValidated(request) && !("login".equals(action)))
        {
            gotoPage("login2.html",request,response);
            return;
        }
        if("login".equals(action))
        {
            UserBean user=new UserBean();
            user.setName(request.getParameter("name"));
            user.setPassword(request.getParameter("password"));
            
            UserCheckBean uc=new UserCheckBean(user);
                 
            if(uc.validate())
            {
                HttpSession session = request.getSession();
                //��user���󱣴浽Session�����У���welcome.jsp��ͨ��
                //<jsp:useBean>����Ԫ�ش�Session�еõ�user����
                session.setAttribute("user",user);
                //��֤�ɹ���������ת��welcome.jsp��
                gotoPage("welcome.jsp", request, response);
            }
            else
            {
                //��֤ʧ�ܣ�������ת��loginerr.jsp��
                gotoPage("loginerr.jsp", request, response);
            }
        }
        //����������action���󣬿��ں����else if...else����м���������
        /*else if
        {
        }
        else
        {
        }*/
    }
    
    /**
    * �ж��û��Ƿ��Ѿ���¼�ˡ�
    */
    private boolean isValidated(HttpServletRequest request)
    {
        HttpSession session = request.getSession();
        if (session.getAttribute("user") != null)
            return true;
        else
            return false;
    }
    
    /**
    * ��������ָ����ҳ�档
    */
    private void gotoPage(String targetURL, HttpServletRequest request,
                          HttpServletResponse response)
                   throws IOException, ServletException
    {
        RequestDispatcher rd;
        rd=request.getRequestDispatcher(targetURL);
        rd.forward(request, response);
    }
}