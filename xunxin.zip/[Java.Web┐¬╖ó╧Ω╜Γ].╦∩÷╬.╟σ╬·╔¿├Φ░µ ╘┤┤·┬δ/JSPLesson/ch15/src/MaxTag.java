package org.sunxin.lesson.jsp.ch15;

import java.io.IOException;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

public class MaxTag extends TagSupport
{
    private int num1;
    private int num2;
    
    public void setNum1(int num1)
    {
        this.num1=num1;
    }
    
    public void setNum2(int num2)
    {
        this.num2=num2;    
    }
    
    public int doEndTag() throws JspException
    {   
        JspWriter out=pageContext.getOut();
        try
        {
            out.print(num1>num2 ? num1:num2);
        }
        catch(IOException e)
        {
            System.err.println(e);
        }
        return EVAL_PAGE;
    }
}