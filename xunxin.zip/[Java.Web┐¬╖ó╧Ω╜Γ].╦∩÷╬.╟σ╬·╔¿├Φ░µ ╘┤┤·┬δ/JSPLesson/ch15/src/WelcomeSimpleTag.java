package org.sunxin.lesson.jsp.ch15;

import java.io.IOException;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

public class WelcomeSimpleTag extends SimpleTagSupport
{
    private JspFragment body;
    private String name; 
    
    public void setName(String name)
    {
        this.name=name;
    }
    
    public void setJspBody(JspFragment jspBody)
    {
        this.body=jspBody;
    }
    
    public void doTag() throws JspException, java.io.IOException
    {
        JspContext jspCtx=getJspContext();
        JspWriter out=jspCtx.getOut();
        out.print(name);
        out.print("��");
        
        //�����������������ǰ������С�
        body.invoke(null);   
    }
}