package org.sunxin.lesson.jsp.ch07;

import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;

public class WelcomeYou extends HttpServlet
{
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        req.setCharacterEncoding("gb2312");
        String user=req.getParameter("user");
        String welcomeMsg=getInitParameter("msg");
        
        resp.setContentType("text/html;charset=gb2312");
        
        PrintWriter out=resp.getWriter();
        
        out.println("<html><head><title>");
        out.println("Welcome Page");
        out.println("</title><body>");
        out.println(welcomeMsg+", "+user);
        out.println("</body></head></html>");
        out.close();
    }
    
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        doGet(req,resp);
    }
}