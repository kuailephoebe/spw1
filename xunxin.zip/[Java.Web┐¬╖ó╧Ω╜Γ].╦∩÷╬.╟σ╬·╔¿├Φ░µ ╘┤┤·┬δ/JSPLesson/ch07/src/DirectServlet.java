package org.sunxin.lesson.jsp.ch07;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class DirectServlet extends HttpServlet
{
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        resp.setContentType("text/html;charset=gb2312");
        
        PrintWriter out=resp.getWriter();
        
        out.println("�����ɵ�����ֱ�����е�Servlet��");
        out.close();
    }
}