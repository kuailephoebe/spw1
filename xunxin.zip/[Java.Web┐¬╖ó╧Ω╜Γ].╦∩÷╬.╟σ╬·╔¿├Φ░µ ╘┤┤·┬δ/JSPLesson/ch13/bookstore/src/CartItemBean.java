package org.sunxin.lesson.jsp.bookstore;

import java.io.Serializable;

public class CartItemBean implements Serializable
{
    private BookBean book=null;
    
    //��ʾѡ����ͼ�������
    private int quantity=0;
    
    public CartItemBean()
    {
    }
    
    public CartItemBean(BookBean book)
    {
        this.book=book;
        this.quantity=1;
    }
    
    public void setBook(BookBean book)
    {
        this.book = book;
    }
    
    public BookBean getBook()
    {
        return book;
    }
    
    public void setQuantity(int quantity)
    {
        this.quantity = quantity;
    }
    
    public int getQuantity()
    {
        return quantity;
    }
    
    /**
    *�õ�����Ŀ����ͼ��۸�ĺϼƣ��ܼ� = ͼ��ĵ��� * ������
    */
    public float getItemPrice()
    {
        float price=book.getPrice()*quantity;
        long val=Math.round(price*100);
        return val/100.0f;
    }
}