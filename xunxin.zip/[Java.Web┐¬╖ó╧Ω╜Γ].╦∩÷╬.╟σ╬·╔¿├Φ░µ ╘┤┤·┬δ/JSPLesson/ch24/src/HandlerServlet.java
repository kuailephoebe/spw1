package org.sunxin.lesson.jsp.ch24;

import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.util.*;

import org.sunxin.lesson.jsp.util.TokenProcessor;

public class HandlerServlet extends HttpServlet
{
    int count=0;
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        resp.setContentType("text/html;charset=GBK");
        PrintWriter out=resp.getWriter();
        
        TokenProcessor processor=TokenProcessor.getInstance();
        if(processor.isTokenValid(req))
        {
            try
            {
                Thread.sleep(5000);
            }
            catch(InterruptedException e)
            {
                System.out.println(e);
            }
                
            System.out.println("submit : "+count);
            if(count%2==1)
                count=0;
            else
                count++;
            out.println("success");
        }
        else
        {
            processor.saveToken(req);
            out.println("���Ѿ��ύ�˱�����ͬһ���������ύ���Ρ�");
        }
        out.close();
    }
}