import javax.servlet.ServletException;
import java.io.*;
import javax.servlet.http.*;

public class SimpleHello extends HttpServlet
{
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        //�õ�PrintWriter����
        PrintWriter out=resp.getWriter();
        //��ͻ��˷����ַ����ݡ�
        out.println("Hello World");
        out.close();
    }
}
