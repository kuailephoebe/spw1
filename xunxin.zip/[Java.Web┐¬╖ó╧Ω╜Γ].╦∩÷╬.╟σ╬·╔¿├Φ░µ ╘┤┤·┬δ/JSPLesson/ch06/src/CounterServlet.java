import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;

public class CounterServlet extends HttpServlet
{
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
               throws ServletException,IOException
    {
        ServletContext context=getServletContext();
        
        Integer count=(Integer)context.getAttribute("counter");
        if(null==count)
        {
            count=new Integer(1);
        }
        else
        {
            count=new Integer(count.intValue()+1);
        }
        
        resp.setContentType("text/html;charset=gb2312");
        PrintWriter out=resp.getWriter();
        
        out.println("<html><head>");
        out.println("<title>ҳ�����ͳ��</title>");
        out.println("</head><body>");
        out.println("��ҳ���ѱ�������"+"<b>"+count+"</b>"+"��");
        out.println("</body></html>");
        context.setAttribute("counter",count);
        out.close();
    }
}