use bookstore;

create table users (
  username         varchar(15) not null primary key,
  password         varchar(15) not null
);

create table roles (
  username         varchar(15) not null,
  rolename         varchar(15) not null,
  primary key (username, rolename)
);

insert into users values('wangwu','1234');
insert into users values('zhaoliu','1234');
insert into roles values('wangwu','sales');
insert into roles values('zhaoliu','market');



insert into users values('zhangsan','1234');
insert into roles values('zhangsan','sales');
insert into roles values('zhangsan','admin');
